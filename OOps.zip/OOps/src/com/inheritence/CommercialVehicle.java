package com.inheritence;

public class CommercialVehicle {
	public void model(String model)
	{
		System.out.println("Model name for commercial vehicle is "+model);
	}
	
	public void price(double price)
	{
		System.out.println("price for commercial is "+price);
	}


}
