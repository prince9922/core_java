package com.inheritence;

public class Showroom {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Tata tt=new Tata();
		CommercialVehicle ts=new Tata();
		
		tt.model("tata tiago");
		tt.price(760089.0);
		
		ts.model("Nexon");
		ts.price(27.08);

	}

}
