package com.inheritence;

public class Tata extends  CommercialVehicle{
	 
	public void model(String model)
	{
		System.out.println("Model name of tata is "+model);
	}
	
	public void price(double price)
	{
		System.out.println("price of tata model is "+price);
	}


}
