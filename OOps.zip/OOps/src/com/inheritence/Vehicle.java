package com.inheritence;

public class Vehicle {
	
	public void model(String model)
	{
		System.out.println("Model name is "+model);
	}
	
	public void price(double price)
	{
		System.out.println("price is "+price);
	}

}
